@echo off
chcp 65001 >nul
echo === Varry Studio: بناء تطبيق ويندوز ===
where node >nul 2>nul
if errorlevel 1 (
  echo يجب تثبيت Node.js اولا من https://nodejs.org
  pause
  exit /b 1
)
call npm install
if errorlevel 1 goto fail
call npm run dist
if errorlevel 1 goto fail
echo.
echo تم! ستجدين ملفات التثبيت داخل المجلد dist
start "" dist
pause
exit /b 0
:fail
echo حدث خطأ اثناء البناء.
pause
exit /b 1
