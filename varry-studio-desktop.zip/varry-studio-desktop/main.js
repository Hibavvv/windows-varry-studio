const { app, BrowserWindow, shell, Menu } = require('electron');
const path = require('path');

// نسخة واحدة فقط من التطبيق
if (!app.requestSingleInstanceLock()) {
  app.quit();
}

let win;

function createWindow() {
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    title: 'Varry Studio',
    backgroundColor: '#ffffff',
    autoHideMenuBar: true,
    webPreferences: {
      partition: 'persist:varry', // تخزين دائم (IndexedDB / localStorage)
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false
    }
  });

  win.loadFile(path.join(__dirname, 'app', 'index.html'));
  win.maximize();

  // فتح الروابط الخارجية في المتصفح الافتراضي
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (/^https?:/i.test(url)) {
      e.preventDefault();
      shell.openExternal(url);
    }
  });
}

app.on('second-instance', () => {
  if (win) {
    if (win.isMinimized()) win.restore();
    win.focus();
  }
});

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
